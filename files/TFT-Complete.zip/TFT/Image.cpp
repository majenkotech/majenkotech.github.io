#include <TFT.h>

uint16_t Image::getWidth() {
    return _width;
}

uint16_t Image::getHeight() {
    return _height;
}

