#include <Widgets.h>

boolean twHBar::render() {
    return render(_x, _y);
}

boolean twHBar::render(int16_t x, int16_t y) {
    _dev->openWindow(_x, _y, _width, _height);
    int32_t pct = _value * (_width - 4) / (_max - _min);

    for (int iy = 0; iy < _height; iy++) {
        for (int ix = 0; ix < _width; ix++) {
            if (iy == 0 || ix == 0 || iy == _height-1 || ix == _width-1) {
                _dev->windowData(_border);
            } else if (iy == 1 || ix == 1 || iy == _height-2 || ix == _width-2) {
                _dev->windowData(_bg);
            } else if (ix <= pct+2) {
                _dev->windowData(_scale);
            } else {
                _dev->windowData(_bg);
            }
        }
    }
    _dev->closeWindow();
    return false;
}
