#include <Widgets.h>

boolean Widget::render() {
    return render(_x, _y);
}

boolean Widget::isEnabled() {
    return _enabled;
}

void Widget::setEnabled(boolean e) {
    _enabled = e;
}

boolean Widget::isActivated() {
    return _activated;
}

void Widget::setActivated(boolean a) {
    _activated = a;
}
