#ifndef _TWBUTTON_H
#define _TWBUTTON_H

#include <Widgets.h>

class twButton : public Widget {
    private:
        boolean _lastPressed;

        uint16_t _bevel;
        const uint8_t *_font;
        uint16_t _bg;
        uint16_t _fg;
        char *_txt;
        uint16_t _bhi;
        uint16_t _blow;

    public:
        twButton(TFT &dev, Touch &ts, int16_t x, int16_t y, int16_t w, int16_t h, char *txt) : Widget(dev, ts, x, y, w, h), _txt(txt),
            _fg(Color::Black), _bg(Color::Gray75), _font(Fonts::Default), _bevel(2), _bhi(Color::Gray85), _blow(Color::Gray45) {}

        boolean render();
        boolean render(int16_t x, int16_t y);

        void setBackgroundColor(uint16_t c) { _bg = c; }
        void setTextColor(uint16_t c) { _fg = c; }
        void setBevel(uint16_t b) { _bevel = b; }
        void setBevelColor(uint16_t hi, uint16_t low) { _bhi = hi; _blow = low; }
        void setFont(const uint8_t *f) { _font = f; }
};

#endif
