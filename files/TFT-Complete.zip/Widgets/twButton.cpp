#include <Widgets.h>

boolean twButton::render() {
    return render(_x, _y);
}

boolean twButton::render(int16_t x, int16_t y) {
	_dev->setFont(_font);
    _x = x;
    _y = y;

	int _tw = _dev->stringWidth(_txt);
	int _th = _dev->stringHeight(_txt);
	
	if (_ts->isPressed() != _lastPressed) {
		_lastPressed = _ts->isPressed();
		if (_lastPressed) {
			if (_ts->x() > _x && _ts->y() > _y && _ts->x() < _x+_width & _ts->y() < _y+_height) {
                setActivated(true);
			} else {
                setActivated(false);
			}
		} else {
            setActivated(false);
		}
	}
	for (int i = 0; i < _bevel; i++) {
		_dev->drawLine(_x,      _y+i,    _x+_width-i-1, _y+i,    isActivated() ? _blow : _bhi); 
		_dev->drawLine(_x+i,    _y+_height-i-1, _x+_width-1,   _y+_height-i-1, isActivated() ? _bhi : _blow); 
		_dev->drawLine(_x+i,    _y,      _x+i,    _y+_height-i-1, isActivated() ? _blow : _bhi); 
		_dev->drawLine(_x+_width-i-1, _y+i,    _x+_width-i-1, _y+_height-1,  isActivated() ? _bhi : _blow);
	}
	_dev->fillRectangle(_x+_bevel,     _y+_bevel,    _width-_bevel-_bevel,  _height/2-_bevel-_th/2, _bg);
	_dev->fillRectangle(_x+_bevel,     _y+_height/2+_th/2, _width-_bevel-_bevel,  _height/2-_bevel-_th/2, _bg);
	_dev->fillRectangle(_x+_bevel,     _y+_height/2-_th/2, _width/2-_tw/2-_bevel,   _th, _bg);
	_dev->fillRectangle(_x+_width/2+_tw/2, _y+_height/2-_th/2, _width/2-_tw/2-_bevel, _th, _bg);
	_dev->setTextColor(_fg, _bg);
	_dev->setCursor(_x + _width/2 - _tw/2, _y + _height/2 - _th/2);
	_dev->print(_txt);
	return isActivated();
}
