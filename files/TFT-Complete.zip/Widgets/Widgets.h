#ifndef _WIDGETS_H
#define _WIDGETS_H

#include <TFT.h>

class Widget {
    public:
        int16_t _x;
        int16_t _y;
        int16_t _width;
        int16_t _height;

        boolean _enabled;
        boolean _activated;


        Touch *_ts;
        TFT *_dev;

        Widget(TFT &dev, Touch &ts, int16_t x, int16_t y, int16_t w, int16_t h) : 
            _dev(&dev), _ts(&ts),
            _x(x), _y(y), _width(w), _height(h), 
            _enabled(true), _activated(false) {}

        Widget(TFT *dev, Touch *ts, int16_t x, int16_t y, int16_t w, int16_t h) : 
            _dev(dev), _ts(ts),
            _x(x), _y(y), _width(w), _height(h), 
            _enabled(true), _activated(false) {}

        virtual boolean render();
        virtual boolean render(int16_t, int16_t) = 0;

        virtual boolean isEnabled();
        virtual void setEnabled(boolean e);

        virtual boolean isActivated();
        virtual void setActivated(boolean a);
};

// Individual widgets are in their own file sets, each prefixed with "tw" 
// for "TFT Widget".
#include "twButton.h"
#include "twHBar.h"

#endif
