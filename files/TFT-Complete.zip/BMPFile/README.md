BMPFile
=======

Bitmap File Renderer (from SD card) for TFT library
