gciWidget
=========

Support for GCI widget files from 4D systems
