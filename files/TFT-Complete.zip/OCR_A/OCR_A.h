#ifndef _FONTS_OCR_A_H
#define _FONTS_OCR_A_H

#include <TFT.h>

namespace Fonts {
        extern const uint8_t OCR_A10[];
        extern const uint8_t OCR_A12[];
        extern const uint8_t OCR_A14[];
        extern const uint8_t OCR_A16[];
        extern const uint8_t OCR_A18[];
        extern const uint8_t OCR_A20[];
        extern const uint8_t OCR_A22[];
        extern const uint8_t OCR_A24[];
        extern const uint8_t OCR_A8[];
};

#endif
