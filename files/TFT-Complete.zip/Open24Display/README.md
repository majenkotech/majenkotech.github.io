Open24Display
=============

Open24Display (7 Segment Display) font for TFT library
