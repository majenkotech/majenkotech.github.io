#ifndef _FONTS_LIBERATION_H
#define _FONTS_LIBERATION_H

#include <TFT.h>

namespace Fonts {
        extern const uint8_t Liberation10[];
        extern const uint8_t Liberation12[];
        extern const uint8_t Liberation14[];
        extern const uint8_t Liberation16[];
        extern const uint8_t Liberation18[];
        extern const uint8_t Liberation20[];
        extern const uint8_t Liberation22[];
        extern const uint8_t Liberation24[];
        extern const uint8_t Liberation26[];
        extern const uint8_t Liberation28[];
        extern const uint8_t Liberation30[];
        extern const uint8_t Liberation32[];
        extern const uint8_t Liberation34[];
        extern const uint8_t Liberation36[];
        extern const uint8_t Liberation8[];
};

#endif
